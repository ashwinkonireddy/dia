<?php

class Admin_Theme_Element_Group_Toggle_Close extends Admin_Theme_Menu_Group
{
	public function render()
	{
		return $this->getElementFooter();
	}
}
?>