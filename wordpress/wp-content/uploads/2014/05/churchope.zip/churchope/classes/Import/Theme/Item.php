<?php

interface Import_Theme_Item
{
	public function import();
}
?>
