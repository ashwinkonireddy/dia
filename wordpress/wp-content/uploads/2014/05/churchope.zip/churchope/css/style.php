<?php
require_once('../../../../wp-load.php');
$custom_style = new Custom_CSS_Style();
$custom_style->getHeaderStyle();
?>