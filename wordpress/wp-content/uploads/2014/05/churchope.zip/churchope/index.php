<?php get_header(); ?>
<div id="contentarea" class="row">
	<div class="grid_12">
		<?php get_template_part('loop'); ?>
    </div>
</div>
<?php get_footer(); ?>